<?php
/**
 * @package CLINICAX
 *
 * APPLICATION-WIDE CONFIGURATION SETTINGS
 *
 * This file contains application-wide configuration settings.  The settings
 * here will be the same regardless of the machine on which the app is running.
 *
 * This configuration should be added to version control.
 *
 * No settings should be added to this file that would need to be changed
 * on a per-machine basic (ie local, staging or production).  Any
 * machine-specific settings should be added to _machine_config.php
 */

/**
 * APPLICATION ROOT DIRECTORY
 * If the application doesn't detect this correctly then it can be set explicitly
 */
if (!GlobalConfig::$APP_ROOT) GlobalConfig::$APP_ROOT = realpath("./");

/**
 * check is needed to ensure asp_tags is not enabled
 */
if (ini_get('asp_tags')) 
	die('<h3>Server Configuration Problem: asp_tags is enabled, but is not compatible with Savant.</h3>'
	. '<p>You can disable asp_tags in .htaccess, php.ini or generate your app with another template engine such as Smarty.</p>');

/**
 * INCLUDE PATH
 * Adjust the include path as necessary so PHP can locate required libraries
 */
set_include_path(
		GlobalConfig::$APP_ROOT . '/libs/' . PATH_SEPARATOR .
		GlobalConfig::$APP_ROOT . '/../phreeze/libs' . PATH_SEPARATOR .
		GlobalConfig::$APP_ROOT . '/vendor/phreeze/phreeze/libs/' . PATH_SEPARATOR .
		get_include_path()
);

/**
 * COMPOSER AUTOLOADER
 * Uncomment if Composer is being used to manage dependencies
 */
// $loader = require 'vendor/autoload.php';
// $loader->setUseIncludePath(true);

/**
 * SESSION CLASSES
 * Any classes that will be stored in the session can be added here
 * and will be pre-loaded on every page
 */
require_once "App/ExampleUser.php";

/**
 * RENDER ENGINE
 * You can use any template system that implements
 * IRenderEngine for the view layer.  Phreeze provides pre-built
 * implementations for Smarty, Savant and plain PHP.
 */
require_once 'verysimple/Phreeze/SavantRenderEngine.php';
GlobalConfig::$TEMPLATE_ENGINE = 'SavantRenderEngine';
GlobalConfig::$TEMPLATE_PATH = GlobalConfig::$APP_ROOT . '/templates/';

/**
 * ROUTE MAP
 * The route map connects URLs to Controller+Method and additionally maps the
 * wildcards to a named parameter so that they are accessible inside the
 * Controller without having to parse the URL for parameters such as IDs
 */
GlobalConfig::$ROUTE_MAP = array(

	// default controller when no route specified
	'GET:' => array('route' => 'Default.Home'),
		
	// example authentication routes
	'GET:loginform' => array('route' => 'SecureExample.LoginForm'),
	'POST:login' => array('route' => 'SecureExample.Login'),
	'GET:secureuser' => array('route' => 'SecureExample.UserPage'),
	'GET:secureadmin' => array('route' => 'SecureExample.AdminPage'),
	'GET:logout' => array('route' => 'SecureExample.Logout'),
		
	// Cliente
	'GET:clientes' => array('route' => 'Cliente.ListView'),
	'GET:cliente/(:num)' => array('route' => 'Cliente.SingleView', 'params' => array('<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>1.0345</td><td bgcolor='#eeeeec' align='right'>1780384</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>1.0349</td><td bgcolor='#eeeeec' align='right'>1804336</td><td bgcolor='#eeeeec'>content_5d5af59d03b9c1_75656424(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>1.0349</td><td bgcolor='#eeeeec' align='right'>1805640</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php' bgcolor='#eeeeec'>...\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php<b>:</b>138</td></tr>
</table></font>
id' => 1)),
	'GET:api/clientes' => array('route' => 'Cliente.Query'),
	'POST:api/cliente' => array('route' => 'Cliente.Create'),
	'GET:api/cliente/(:num)' => array('route' => 'Cliente.Read', 'params' => array('<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>1.0345</td><td bgcolor='#eeeeec' align='right'>1780384</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>1.0349</td><td bgcolor='#eeeeec' align='right'>1804336</td><td bgcolor='#eeeeec'>content_5d5af59d03b9c1_75656424(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>1.0373</td><td bgcolor='#eeeeec' align='right'>1806120</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php' bgcolor='#eeeeec'>...\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php<b>:</b>148</td></tr>
</table></font>
id' => 2)),
	'PUT:api/cliente/(:num)' => array('route' => 'Cliente.Update', 'params' => array('<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>1.0345</td><td bgcolor='#eeeeec' align='right'>1780384</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>1.0349</td><td bgcolor='#eeeeec' align='right'>1804336</td><td bgcolor='#eeeeec'>content_5d5af59d03b9c1_75656424(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>1.0395</td><td bgcolor='#eeeeec' align='right'>1806600</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php' bgcolor='#eeeeec'>...\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php<b>:</b>152</td></tr>
</table></font>
id' => 2)),
	'DELETE:api/cliente/(:num)' => array('route' => 'Cliente.Delete', 'params' => array('<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>1.0345</td><td bgcolor='#eeeeec' align='right'>1780384</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>1.0349</td><td bgcolor='#eeeeec' align='right'>1804336</td><td bgcolor='#eeeeec'>content_5d5af59d03b9c1_75656424(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>1.0418</td><td bgcolor='#eeeeec' align='right'>1807080</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php' bgcolor='#eeeeec'>...\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php<b>:</b>156</td></tr>
</table></font>
id' => 2)),
		
	// Exame
	'GET:exames' => array('route' => 'Exame.ListView'),
	'GET:exame/(:num)' => array('route' => 'Exame.SingleView', 'params' => array('<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>1.0345</td><td bgcolor='#eeeeec' align='right'>1780384</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>1.0349</td><td bgcolor='#eeeeec' align='right'>1804336</td><td bgcolor='#eeeeec'>content_5d5af59d03b9c1_75656424(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>1.0441</td><td bgcolor='#eeeeec' align='right'>1807560</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php' bgcolor='#eeeeec'>...\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php<b>:</b>138</td></tr>
</table></font>
id' => 1)),
	'GET:api/exames' => array('route' => 'Exame.Query'),
	'POST:api/exame' => array('route' => 'Exame.Create'),
	'GET:api/exame/(:num)' => array('route' => 'Exame.Read', 'params' => array('<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>1.0345</td><td bgcolor='#eeeeec' align='right'>1780384</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>1.0349</td><td bgcolor='#eeeeec' align='right'>1804336</td><td bgcolor='#eeeeec'>content_5d5af59d03b9c1_75656424(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>1.0466</td><td bgcolor='#eeeeec' align='right'>1824424</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php' bgcolor='#eeeeec'>...\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php<b>:</b>148</td></tr>
</table></font>
id' => 2)),
	'PUT:api/exame/(:num)' => array('route' => 'Exame.Update', 'params' => array('<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>1.0345</td><td bgcolor='#eeeeec' align='right'>1780384</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>1.0349</td><td bgcolor='#eeeeec' align='right'>1804336</td><td bgcolor='#eeeeec'>content_5d5af59d03b9c1_75656424(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>1.0488</td><td bgcolor='#eeeeec' align='right'>1824904</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php' bgcolor='#eeeeec'>...\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php<b>:</b>152</td></tr>
</table></font>
id' => 2)),
	'DELETE:api/exame/(:num)' => array('route' => 'Exame.Delete', 'params' => array('<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>1.0345</td><td bgcolor='#eeeeec' align='right'>1780384</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>1.0349</td><td bgcolor='#eeeeec' align='right'>1804336</td><td bgcolor='#eeeeec'>content_5d5af59d03b9c1_75656424(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>1.0511</td><td bgcolor='#eeeeec' align='right'>1825384</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php' bgcolor='#eeeeec'>...\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php<b>:</b>156</td></tr>
</table></font>
id' => 2)),

	// catch any broken API urls
	'GET:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'PUT:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'POST:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'DELETE:api/(:any)' => array('route' => 'Default.ErrorApi404')
);

/**
 * FETCHING STRATEGY
 * You may uncomment any of the lines below to specify always eager fetching.
 * Alternatively, you can copy/paste to a specific page for one-time eager fetching
 * If you paste into a controller method, replace $G_PHREEZER with $this->Phreezer
 */
// $GlobalConfig->GetInstance()->GetPhreezer()->SetLoadType("<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>1.0345</td><td bgcolor='#eeeeec' align='right'>1780384</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>1.0349</td><td bgcolor='#eeeeec' align='right'>1804336</td><td bgcolor='#eeeeec'>content_5d5af59d03b9c1_75656424(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>1.0533</td><td bgcolor='#eeeeec' align='right'>1826808</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php' bgcolor='#eeeeec'>...\befd993e82c1374ab50346f6cb98311336cfa88e.file._app_config.php.tpl.php<b>:</b>183</td></tr>
</table></font>
Exame","id_PESSOA",KM_LOAD_EAGER); // KM_LOAD_INNER | KM_LOAD_EAGER | KM_LOAD_LAZY
?>