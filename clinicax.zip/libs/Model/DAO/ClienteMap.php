<?php
/** @package    <br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6176</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>35</td></tr>
</table></font>
Clinicax::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/IDaoMap.php");
require_once("verysimple/Phreeze/IDaoMap2.php");

/**
 * ClienteMap is a static class with functions used to get FieldMap and KeyMap information that
 * is used by Phreeze to map the ClienteDAO to the cliente datastore.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * You can override the default fetching strategies for KeyMaps in _config.php.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @package <br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6201</td><td bgcolor='#eeeeec' align='right'>1442232</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>55</td></tr>
</table></font>
Clinicax::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class ClienteMap implements IDaoMap, IDaoMap2
{

	private static $KM;
	private static $FM;
	
	/**
	 * {@inheritdoc}
	 */
	public static function AddMap($property,FieldMap $map)
	{
		self::GetFieldMaps();
		self::$FM[$property] = $map;
	}
	
	/**
	 * {@inheritdoc}
	 */
	public static function SetFetchingStrategy($property,$loadType)
	{
		self::GetKeyMaps();
		self::$KM[$property]->LoadType = $loadType;
	}

	/**
	 * {@inheritdoc}
	 */
	public static function GetFieldMaps()
	{
		if (self::$FM == null)
		{
			self::$FM = Array();
			self::$FM["<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6228</td><td bgcolor='#eeeeec' align='right'>1443184</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>97</td></tr>
</table></font>
Id"] = new FieldMap("<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6253</td><td bgcolor='#eeeeec' align='right'>1443664</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>98</td></tr>
</table></font>
Id","cliente","id",true,FM_TYPE_INT,11,null,true);
			self::$FM["<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6280</td><td bgcolor='#eeeeec' align='right'>1444144</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>97</td></tr>
</table></font>
Nome"] = new FieldMap("<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6309</td><td bgcolor='#eeeeec' align='right'>1444624</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>98</td></tr>
</table></font>
Nome","cliente","nome",false,FM_TYPE_VARCHAR,50,null,false);
			self::$FM["<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6331</td><td bgcolor='#eeeeec' align='right'>1461488</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>97</td></tr>
</table></font>
NomeMae"] = new FieldMap("<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6355</td><td bgcolor='#eeeeec' align='right'>1461968</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>98</td></tr>
</table></font>
NomeMae","cliente","nome_mae",false,FM_TYPE_VARCHAR,50,null,false);
			self::$FM["<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6379</td><td bgcolor='#eeeeec' align='right'>1462448</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>97</td></tr>
</table></font>
Cpf"] = new FieldMap("<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6404</td><td bgcolor='#eeeeec' align='right'>1462928</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>98</td></tr>
</table></font>
Cpf","cliente","CPF",false,FM_TYPE_VARCHAR,50,null,false);
			self::$FM["<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6430</td><td bgcolor='#eeeeec' align='right'>1463408</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>97</td></tr>
</table></font>
Endereco"] = new FieldMap("<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6457</td><td bgcolor='#eeeeec' align='right'>1463888</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>98</td></tr>
</table></font>
Endereco","cliente","endereco",false,FM_TYPE_VARCHAR,150,null,false);
			self::$FM["<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6485</td><td bgcolor='#eeeeec' align='right'>1546288</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>97</td></tr>
</table></font>
Telefone"] = new FieldMap("<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6511</td><td bgcolor='#eeeeec' align='right'>1546768</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>98</td></tr>
</table></font>
Telefone","cliente","telefone",false,FM_TYPE_VARCHAR,50,null,false);
		}
		return self::$FM;
	}

	/**
	 * {@inheritdoc}
	 */
	public static function GetKeyMaps()
	{
		if (self::$KM == null)
		{
			self::$KM = Array();
			self::$KM["id_PESSOA"] = new KeyMap("id_PESSOA", "<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6535</td><td bgcolor='#eeeeec' align='right'>1547720</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>133</td></tr>
</table></font>
Id", "<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6559</td><td bgcolor='#eeeeec' align='right'>1548200</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>134</td></tr>
</table></font>
Exame", "<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.6171</td><td bgcolor='#eeeeec' align='right'>1417096</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.6175</td><td bgcolor='#eeeeec' align='right'>1441752</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.6582</td><td bgcolor='#eeeeec' align='right'>1548680</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>135</td></tr>
</table></font>
IdCliente", KM_TYPE_ONETOMANY, KM_LOAD_LAZY);  // use KM_LOAD_EAGER with caution here (one-to-one relationships only)
		}
		return self::$KM;
	}

}

?>