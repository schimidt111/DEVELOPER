<?php
/** @package    CLINICAX::Controller */

/** import supporting libraries */
require_once("AppBaseController.php");
require_once("Model/Exame.php");

/**
 * ExameController is the controller class for the Exame object.  The
 * controller is responsible for processing input from the user, reading/updating
 * the model as necessary and displaying the appropriate view.
 *
 * @package CLINICAX::Controller
 * @author ClassBuilder
 * @version 1.0
 */
class ExameController extends AppBaseController
{

	/**
	 * Override here for any controller-specific functionality
	 *
	 * @inheritdocs
	 */
	protected function Init()
	{
		parent::Init();

		// TODO: add controller-wide bootstrap code
		
		// TODO: if authentiation is required for this entire controller, for example:
		// $this->RequirePermission(ExampleUser::$PERMISSION_USER,'SecureExample.LoginForm');
	}

	/**
	 * Displays a list view of Exame objects
	 */
	public function ListView()
	{
		$this->Render();
	}

	/**
	 * API Method queries for Exame records and render as JSON
	 */
	public function Query()
	{
		try
		{
			$criteria = new ExameCriteria();
			
			// TODO: this will limit results based on all properties included in the filter list 
			$filter = RequestUtil::Get('filter');
			if ($filter) $criteria->AddFilter(
				new CriteriaFilter('<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1217968</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>104</td></tr>
</table></font>
Id,<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1330</td><td bgcolor='#eeeeec' align='right'>1218448</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>104</td></tr>
</table></font>
IdCliente,<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1354</td><td bgcolor='#eeeeec' align='right'>1218928</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>104</td></tr>
</table></font>
Descricao,<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1374</td><td bgcolor='#eeeeec' align='right'>1219408</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>104</td></tr>
</table></font>
Valor'
				, '%'.$filter.'%')
			);

			// TODO: this is generic query filtering based only on criteria properties
			foreach (array_keys($_REQUEST) as $prop)
			{
				$prop_normal = ucfirst($prop);
				$prop_equals = $prop_normal.'_Equals';

				if (property_exists($criteria, $prop_normal))
				{
					$criteria->$prop_normal = RequestUtil::Get($prop);
				}
				elseif (property_exists($criteria, $prop_equals))
				{
					// this is a convenience so that the _Equals suffix is not needed
					$criteria->$prop_equals = RequestUtil::Get($prop);
				}
			}

			$output = new stdClass();

			// if a sort order was specified then specify in the criteria
 			$output->orderBy = RequestUtil::Get('orderBy');
 			$output->orderDesc = RequestUtil::Get('orderDesc') != '';
 			if ($output->orderBy) $criteria->SetOrder($output->orderBy, $output->orderDesc);

			$page = RequestUtil::Get('page');

			if ($page != '')
			{
				// if page is specified, use this instead (at the expense of one extra count query)
				$pagesize = $this->GetDefaultPageSize();

				$exames = $this->Phreezer->Query('Exame',$criteria)->GetDataPage($page, $pagesize);
				$output->rows = $exames->ToObjectArray(true,$this->SimpleObjectParams());
				$output->totalResults = $exames->TotalResults;
				$output->totalPages = $exames->TotalPages;
				$output->pageSize = $exames->PageSize;
				$output->currentPage = $exames->CurrentPage;
			}
			else
			{
				// return all results
				$exames = $this->Phreezer->Query('Exame',$criteria);
				$output->rows = $exames->ToObjectArray(true, $this->SimpleObjectParams());
				$output->totalResults = count($output->rows);
				$output->totalPages = 1;
				$output->pageSize = $output->totalResults;
				$output->currentPage = 1;
			}


			$this->RenderJSON($output, $this->JSONPCallback());
		}
		catch (Exception $ex)
		{
			$this->RenderExceptionJSON($ex);
		}
	}

	/**
	 * API Method retrieves a single Exame record and render as JSON
	 */
	public function Read()
	{
		try
		{
			$pk = $this->GetRouter()->GetUrlParam('<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1394</td><td bgcolor='#eeeeec' align='right'>1219888</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>185</td></tr>
</table></font>
id');
			$exame = $this->Phreezer->Get('Exame',$pk);
			$this->RenderJSON($exame, $this->JSONPCallback(), true, $this->SimpleObjectParams());
		}
		catch (Exception $ex)
		{
			$this->RenderExceptionJSON($ex);
		}
	}

	/**
	 * API Method inserts a new Exame record and render response as JSON
	 */
	public function Create()
	{
		try
		{
						
			$json = json_decode(RequestUtil::GetBody());

			if (!$json)
			{
				throw new Exception('The request body does not contain valid JSON');
			}

			$exame = new Exame($this->Phreezer);

			// TODO: any fields that should not be inserted by the user should be commented out

			// this is an auto-increment.  uncomment if updating is allowed
			// $exame-><br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1416</td><td bgcolor='#eeeeec' align='right'>1236752</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>232</td></tr>
</table></font>
Id = $this->SafeGetVal($json, '<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1438</td><td bgcolor='#eeeeec' align='right'>1237232</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>233</td></tr>
</table></font>
id');

			$exame-><br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1460</td><td bgcolor='#eeeeec' align='right'>1237712</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>249</td></tr>
</table></font>
IdCliente = $this->SafeGetVal($json, '<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1483</td><td bgcolor='#eeeeec' align='right'>1238192</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>250</td></tr>
</table></font>
idCliente');
			$exame-><br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1506</td><td bgcolor='#eeeeec' align='right'>1238672</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>249</td></tr>
</table></font>
Descricao = $this->SafeGetVal($json, '<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1531</td><td bgcolor='#eeeeec' align='right'>1239152</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>250</td></tr>
</table></font>
descricao');
			$exame-><br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1553</td><td bgcolor='#eeeeec' align='right'>1256016</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>249</td></tr>
</table></font>
Valor = $this->SafeGetVal($json, '<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1574</td><td bgcolor='#eeeeec' align='right'>1256496</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>250</td></tr>
</table></font>
valor');

			$exame->Validate();
			$errors = $exame->GetValidationErrors();

			if (count($errors) > 0)
			{
				$this->RenderErrorJSON('Please check the form for errors',$errors);
			}
			else
			{
				$exame->Save();
				$this->RenderJSON($exame, $this->JSONPCallback(), true, $this->SimpleObjectParams());
			}

		}
		catch (Exception $ex)
		{
			$this->RenderExceptionJSON($ex);
		}
	}

	/**
	 * API Method updates an existing Exame record and render response as JSON
	 */
	public function Update()
	{
		try
		{
						
			$json = json_decode(RequestUtil::GetBody());

			if (!$json)
			{
				throw new Exception('The request body does not contain valid JSON');
			}

			$pk = $this->GetRouter()->GetUrlParam('<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1596</td><td bgcolor='#eeeeec' align='right'>1256976</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>302</td></tr>
</table></font>
id');
			$exame = $this->Phreezer->Get('Exame',$pk);

			// TODO: any fields that should not be updated by the user should be commented out

			// this is a primary key.  uncomment if updating is allowed
			// $exame-><br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1622</td><td bgcolor='#eeeeec' align='right'>1257456</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>318</td></tr>
</table></font>
Id = $this->SafeGetVal($json, '<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1644</td><td bgcolor='#eeeeec' align='right'>1257936</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>319</td></tr>
</table></font>
id', $exame-><br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1666</td><td bgcolor='#eeeeec' align='right'>1274800</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>321</td></tr>
</table></font>
Id);

			$exame-><br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1687</td><td bgcolor='#eeeeec' align='right'>1275280</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>350</td></tr>
</table></font>
IdCliente = $this->SafeGetVal($json, '<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1710</td><td bgcolor='#eeeeec' align='right'>1275760</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>351</td></tr>
</table></font>
idCliente', $exame-><br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1730</td><td bgcolor='#eeeeec' align='right'>1276240</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>353</td></tr>
</table></font>
IdCliente);
			$exame-><br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1754</td><td bgcolor='#eeeeec' align='right'>1276720</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>350</td></tr>
</table></font>
Descricao = $this->SafeGetVal($json, '<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1778</td><td bgcolor='#eeeeec' align='right'>1277200</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>351</td></tr>
</table></font>
descricao', $exame-><br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1799</td><td bgcolor='#eeeeec' align='right'>1294064</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>353</td></tr>
</table></font>
Descricao);
			$exame-><br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1821</td><td bgcolor='#eeeeec' align='right'>1294544</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>350</td></tr>
</table></font>
Valor = $this->SafeGetVal($json, '<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1843</td><td bgcolor='#eeeeec' align='right'>1295024</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>351</td></tr>
</table></font>
valor', $exame-><br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1864</td><td bgcolor='#eeeeec' align='right'>1295504</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>353</td></tr>
</table></font>
Valor);

			$exame->Validate();
			$errors = $exame->GetValidationErrors();

			if (count($errors) > 0)
			{
				$this->RenderErrorJSON('Please check the form for errors',$errors);
			}
			else
			{
				$exame->Save();
				$this->RenderJSON($exame, $this->JSONPCallback(), true, $this->SimpleObjectParams());
			}


		}
		catch (Exception $ex)
		{


			$this->RenderExceptionJSON($ex);
		}
	}

	/**
	 * API Method deletes an existing Exame record and render response as JSON
	 */
	public function Delete()
	{
		try
		{
						
			// TODO: if a soft delete is prefered, change this to update the deleted flag instead of hard-deleting

			$pk = $this->GetRouter()->GetUrlParam('<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1197440</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.1303</td><td bgcolor='#eeeeec' align='right'>1216368</td><td bgcolor='#eeeeec'>content_5d5af59a551585_01461755(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.1886</td><td bgcolor='#eeeeec' align='right'>1295984</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php' bgcolor='#eeeeec'>...\765d323bb4d98fb09a09c5ce72abb1b365f365fb.file.Controller.php.tpl.php<b>:</b>409</td></tr>
</table></font>
id');
			$exame = $this->Phreezer->Get('Exame',$pk);

			$exame->Delete();

			$output = new stdClass();

			$this->RenderJSON($output, $this->JSONPCallback());

		}
		catch (Exception $ex)
		{
			$this->RenderExceptionJSON($ex);
		}
	}
}

?>
