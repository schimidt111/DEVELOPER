/**
 * backbone model definitions for CLINICAX
 */

/**
 * Use emulated HTTP if the server doesn't support PUT/DELETE or application/json requests
 */
Backbone.emulateHTTP = false;
Backbone.emulateJSON = false;

var model = {};

/**
 * long polling duration in miliseconds.  (5000 = recommended, 0 = disabled)
 * warning: setting this to a low number will increase server load
 */
model.longPollDuration = 0;

/**
 * whether to refresh the collection immediately after a model is updated
 */
model.reloadCollectionOnModelUpdate = true;


/**
 * a default sort method for sorting collection items.  this will sort the collection
 * based on the orderBy and orderDesc property that was used on the last fetch call
 * to the server. 
 */
model.AbstractCollection = Backbone.Collection.extend({
	totalResults: 0,
	totalPages: 0,
	currentPage: 0,
	pageSize: 0,
	orderBy: '',
	orderDesc: false,
	lastResponseText: null,
	lastRequestParams: null,
	collectionHasChanged: true,
	
	/**
	 * fetch the collection from the server using the same options and 
	 * parameters as the previous fetch
	 */
	refetch: function() {
		this.fetch({ data: this.lastRequestParams })
	},
	
	/* uncomment to debug fetch event triggers
	fetch: function(options) {
            this.constructor.__super__.fetch.apply(this, arguments);
	},
	// */
	
	/**
	 * client-side sorting baesd on the orderBy and orderDesc parameters that
	 * were used to fetch the data from the server.  Backbone ignores the
	 * order of records coming from the server so we have to sort them ourselves
	 */
	comparator: function(a,b) {
		
		var result = 0;
		var options = this.lastRequestParams;
		
		if (options && options.orderBy) {
			
			// lcase the first letter of the property name
			var propName = options.orderBy.charAt(0).toLowerCase() + options.orderBy.slice(1);
			var aVal = a.get(propName);
			var bVal = b.get(propName);
			
			if (isNaN(aVal) || isNaN(bVal)) {
				// treat comparison as case-insensitive strings
				aVal = aVal ? aVal.toLowerCase() : '';
				bVal = bVal ? bVal.toLowerCase() : '';
			} else {
				// treat comparision as a number
				aVal = Number(aVal);
				bVal = Number(bVal);
			}
			
			if (aVal < bVal) {
				result = options.orderDesc ? 1 : -1;
			} else if (aVal > bVal) {
				result = options.orderDesc ? -1 : 1;
			}
		}
		
		return result;

	},
	/**
	 * override parse to track changes and handle pagination
	 * if the server call has returned page data
	 */
	parse: function(response, options) {

		// the response is already decoded into object form, but it's easier to
		// compary the stringified version.  some earlier versions of backbone did
		// not include the raw response so there is some legacy support here
		var responseText = options && options.xhr ? options.xhr.responseText : JSON.stringify(response);
		this.collectionHasChanged = (this.lastResponseText != responseText);
		this.lastRequestParams = options ? options.data : undefined;
		
		// if the collection has changed then we need to force a re-sort because backbone will
		// only resort the data if a property in the model has changed
		if (this.lastResponseText && this.collectionHasChanged) this.sort({ silent:true });
		
		this.lastResponseText = responseText;
		
		var rows;

		if (response.currentPage) {
			rows = response.rows;
			this.totalResults = response.totalResults;
			this.totalPages = response.totalPages;
			this.currentPage = response.currentPage;
			this.pageSize = response.pageSize;
			this.orderBy = response.orderBy;
			this.orderDesc = response.orderDesc;
		} else {
			rows = response;
			this.totalResults = rows.length;
			this.totalPages = 1;
			this.currentPage = 1;
			this.pageSize = this.totalResults;
			this.orderBy = response.orderBy;
			this.orderDesc = response.orderDesc;
		}

		return rows;
	}
});

/**
 * Cliente Backbone Model
 */
model.ClienteModel = Backbone.Model.extend({
	urlRoot: 'api/cliente',
	idAttribute: '<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1564632</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>185</td></tr>
</table></font>
id',
	<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7525</td><td bgcolor='#eeeeec' align='right'>1566712</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>197</td></tr>
</table></font>
id: '',
	<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7550</td><td bgcolor='#eeeeec' align='right'>1567192</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>197</td></tr>
</table></font>
nome: '',
	<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7575</td><td bgcolor='#eeeeec' align='right'>1567672</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>197</td></tr>
</table></font>
nomeMae: '',
	<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7600</td><td bgcolor='#eeeeec' align='right'>1568152</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>197</td></tr>
</table></font>
cpf: '',
	<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7625</td><td bgcolor='#eeeeec' align='right'>1585016</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>197</td></tr>
</table></font>
endereco: '',
	<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7651</td><td bgcolor='#eeeeec' align='right'>1585496</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>197</td></tr>
</table></font>
telefone: '',
	defaults: {
		'<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7679</td><td bgcolor='#eeeeec' align='right'>1585976</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>211</td></tr>
</table></font>
id': null,
		'<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7706</td><td bgcolor='#eeeeec' align='right'>1586456</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>211</td></tr>
</table></font>
nome': '',
		'<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7731</td><td bgcolor='#eeeeec' align='right'>1586936</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>211</td></tr>
</table></font>
nomeMae': '',
		'<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7758</td><td bgcolor='#eeeeec' align='right'>1587416</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>211</td></tr>
</table></font>
cpf': '',
		'<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7783</td><td bgcolor='#eeeeec' align='right'>1604280</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>211</td></tr>
</table></font>
endereco': '',
		'<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7809</td><td bgcolor='#eeeeec' align='right'>1604760</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>211</td></tr>
</table></font>
telefone': ''
	}
});

/**
 * Cliente Backbone Collection
 */
model.ClienteCollection = model.AbstractCollection.extend({
	url: 'api/clientes',
	model: model.ClienteModel
});

/**
 * Exame Backbone Model
 */
model.ExameModel = Backbone.Model.extend({
	urlRoot: 'api/exame',
	idAttribute: '<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7835</td><td bgcolor='#eeeeec' align='right'>1605240</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>185</td></tr>
</table></font>
id',
	<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7858</td><td bgcolor='#eeeeec' align='right'>1605720</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>197</td></tr>
</table></font>
id: '',
	<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7882</td><td bgcolor='#eeeeec' align='right'>1606200</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>197</td></tr>
</table></font>
idCliente: '',
	<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7906</td><td bgcolor='#eeeeec' align='right'>1606680</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>197</td></tr>
</table></font>
descricao: '',
	<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7932</td><td bgcolor='#eeeeec' align='right'>1623544</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>197</td></tr>
</table></font>
valor: '',
	defaults: {
		'<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7958</td><td bgcolor='#eeeeec' align='right'>1624024</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>211</td></tr>
</table></font>
id': null,
		'<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.7984</td><td bgcolor='#eeeeec' align='right'>1624504</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>211</td></tr>
</table></font>
idCliente': '',
		'<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.8011</td><td bgcolor='#eeeeec' align='right'>1624984</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>211</td></tr>
</table></font>
descricao': '',
		'<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0003</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0016</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.7499</td><td bgcolor='#eeeeec' align='right'>1539344</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>200</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.7502</td><td bgcolor='#eeeeec' align='right'>1563328</td><td bgcolor='#eeeeec'>content_5d5af59bccfc53_90564203(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.8035</td><td bgcolor='#eeeeec' align='right'>1625464</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php' bgcolor='#eeeeec'>...\fd21b49964234ea967ae77f462424adacc334eea.file.model.js.tpl.php<b>:</b>211</td></tr>
</table></font>
valor': ''
	}
});

/**
 * Exame Backbone Collection
 */
model.ExameCollection = model.AbstractCollection.extend({
	url: 'api/exames',
	model: model.ExameModel
});

