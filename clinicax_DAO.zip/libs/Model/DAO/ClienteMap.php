<?php
/** @package    <br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>35</td></tr>
</table></font>
Clinicax::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/IDaoMap.php");
require_once("verysimple/Phreeze/IDaoMap2.php");

/**
 * ClienteMap is a static class with functions used to get FieldMap and KeyMap information that
 * is used by Phreeze to map the ClienteDAO to the cliente datastore.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * You can override the default fetching strategies for KeyMaps in _config.php.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @package <br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4445</td><td bgcolor='#eeeeec' align='right'>981056</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>55</td></tr>
</table></font>
Clinicax::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class ClienteMap implements IDaoMap, IDaoMap2
{

	private static $KM;
	private static $FM;
	
	/**
	 * {@inheritdoc}
	 */
	public static function AddMap($property,FieldMap $map)
	{
		self::GetFieldMaps();
		self::$FM[$property] = $map;
	}
	
	/**
	 * {@inheritdoc}
	 */
	public static function SetFetchingStrategy($property,$loadType)
	{
		self::GetKeyMaps();
		self::$KM[$property]->LoadType = $loadType;
	}

	/**
	 * {@inheritdoc}
	 */
	public static function GetFieldMaps()
	{
		if (self::$FM == null)
		{
			self::$FM = Array();
			self::$FM["<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4467</td><td bgcolor='#eeeeec' align='right'>982008</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>97</td></tr>
</table></font>
Id"] = new FieldMap("<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4489</td><td bgcolor='#eeeeec' align='right'>982488</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>98</td></tr>
</table></font>
Id","cliente","id",true,FM_TYPE_INT,11,null,true);
			self::$FM["<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4516</td><td bgcolor='#eeeeec' align='right'>982968</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>97</td></tr>
</table></font>
Nome"] = new FieldMap("<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4540</td><td bgcolor='#eeeeec' align='right'>983448</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>98</td></tr>
</table></font>
Nome","cliente","nome",false,FM_TYPE_VARCHAR,50,null,false);
			self::$FM["<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4563</td><td bgcolor='#eeeeec' align='right'>1000312</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>97</td></tr>
</table></font>
NomeMae"] = new FieldMap("<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4590</td><td bgcolor='#eeeeec' align='right'>1000792</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>98</td></tr>
</table></font>
NomeMae","cliente","nome_mae",false,FM_TYPE_VARCHAR,50,null,false);
			self::$FM["<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4619</td><td bgcolor='#eeeeec' align='right'>1001272</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>97</td></tr>
</table></font>
Cpf"] = new FieldMap("<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4644</td><td bgcolor='#eeeeec' align='right'>1001752</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>98</td></tr>
</table></font>
Cpf","cliente","CPF",false,FM_TYPE_VARCHAR,50,null,false);
			self::$FM["<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4669</td><td bgcolor='#eeeeec' align='right'>1002232</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>97</td></tr>
</table></font>
Endereco"] = new FieldMap("<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4695</td><td bgcolor='#eeeeec' align='right'>1002712</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>98</td></tr>
</table></font>
Endereco","cliente","endereco",false,FM_TYPE_VARCHAR,150,null,false);
			self::$FM["<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4720</td><td bgcolor='#eeeeec' align='right'>1019576</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>97</td></tr>
</table></font>
Telefone"] = new FieldMap("<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4743</td><td bgcolor='#eeeeec' align='right'>1020056</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>98</td></tr>
</table></font>
Telefone","cliente","telefone",false,FM_TYPE_VARCHAR,50,null,false);
		}
		return self::$FM;
	}

	/**
	 * {@inheritdoc}
	 */
	public static function GetKeyMaps()
	{
		if (self::$KM == null)
		{
			self::$KM = Array();
			self::$KM["id_PESSOA"] = new KeyMap("id_PESSOA", "<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4766</td><td bgcolor='#eeeeec' align='right'>1021008</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>133</td></tr>
</table></font>
Id", "<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4789</td><td bgcolor='#eeeeec' align='right'>1021488</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>134</td></tr>
</table></font>
Exame", "<br />
<font size='1'><table class='xdebug-error xe-deprecated' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
<tr><th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Deprecated: Function create_function() is deprecated in C:\wamp64\www\phreeze\libs\smarty\plugins\modifier.studlycaps.php on line <i>23</i></th></tr>
<tr><th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th></tr>
<tr><th align='center' bgcolor='#eeeeec'>#</th><th align='left' bgcolor='#eeeeec'>Time</th><th align='left' bgcolor='#eeeeec'>Memory</th><th align='left' bgcolor='#eeeeec'>Function</th><th align='left' bgcolor='#eeeeec'>Location</th></tr>
<tr><td bgcolor='#eeeeec' align='center'>1</td><td bgcolor='#eeeeec' align='center'>0.0002</td><td bgcolor='#eeeeec' align='right'>413952</td><td bgcolor='#eeeeec'>{main}(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>0</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>2</td><td bgcolor='#eeeeec' align='center'>0.0022</td><td bgcolor='#eeeeec' align='right'>515968</td><td bgcolor='#eeeeec'>Dispatcher::Dispatch(  )</td><td title='C:\wamp64\www\phreeze\builder\index.php' bgcolor='#eeeeec'>...\index.php<b>:</b>22</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>3</td><td bgcolor='#eeeeec' align='center'>0.0034</td><td bgcolor='#eeeeec' align='right'>655816</td><td bgcolor='#eeeeec'>GeneratorController->Generate(  )</td><td title='C:\wamp64\www\phreeze\libs\verysimple\Phreeze\Dispatcher.php' bgcolor='#eeeeec'>...\Dispatcher.php<b>:</b>161</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>4</td><td bgcolor='#eeeeec' align='center'>0.4420</td><td bgcolor='#eeeeec' align='right'>955920</td><td bgcolor='#eeeeec'>Smarty->fetch(  )</td><td title='C:\wamp64\www\phreeze\builder\libs\Controller\GeneratorController.php' bgcolor='#eeeeec'>...\GeneratorController.php<b>:</b>268</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>5</td><td bgcolor='#eeeeec' align='center'>0.4423</td><td bgcolor='#eeeeec' align='right'>980576</td><td bgcolor='#eeeeec'>content_5d5af59b732739_53080666(  )</td><td title='C:\wamp64\www\phreeze\libs\smarty\sysplugins\smarty_internal_templatebase.php' bgcolor='#eeeeec'>...\smarty_internal_templatebase.php<b>:</b>182</td></tr>
<tr><td bgcolor='#eeeeec' align='center'>6</td><td bgcolor='#eeeeec' align='center'>0.4813</td><td bgcolor='#eeeeec' align='right'>1021968</td><td bgcolor='#eeeeec'>smarty_modifier_studlycaps(  )</td><td title='C:\wamp64\www\phreeze\builder\temp\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php' bgcolor='#eeeeec'>...\225686b48134423c50691e003e1325be3d59b6ec.file.ModelMap.php.tpl.php<b>:</b>135</td></tr>
</table></font>
IdCliente", KM_TYPE_ONETOMANY, KM_LOAD_LAZY);  // use KM_LOAD_EAGER with caution here (one-to-one relationships only)
		}
		return self::$KM;
	}

}

?>